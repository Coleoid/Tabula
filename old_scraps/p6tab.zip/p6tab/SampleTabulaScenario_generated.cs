using System;
using System.Collections.Generic;
using System.Linq;

namespace Tabula
{
    public interface IGeneratedScenario
    {
        void MainScenario(TabulaStepRunner runner);
    }

    public class SampleTabulaScenario_generated : IGeneratedScenario
    {
        EditPersonWorkflow EditPerson;
        public void MainScenario(TabulaStepRunner runner)
        {
            //  Instances of Workflows which are used by this scenario
            EditPerson = new EditPersonWorkflow();

            para_from_021_to_025(runner);
        }

        public void para_from_021_to_025(TabulaStepRunner runner)
        {
            runner.Do(() =>   EditPerson.AddPerson("Sammy", "Weezel"),     "SampleTabulaScenario.scn:21", "wfEditPerson.AddPerson(\"Sammy\", \"Weezel\")");
            runner.Unfound(   "Add another dude named \"Bart\" \"Wiegmans\"",     "SampleTabulaScenario.scn:22");
            runner.Do(() =>   EditPerson.AddPerson_but_fail("Formica", "Farragut"),     "SampleTabulaScenario.scn:23", "wfEditPerson.AddPerson_but_fail(\"Formica\", \"Farragut\")");
            runner.Do(() =>   EditPerson.Add_some_more_but_die_horribly("Paulie"),     "SampleTabulaScenario.scn:24", "wfEditPerson.Add_some_more_but_die_horribly(\"Paulie\")");
            runner.Do(() =>   EditPerson.AddPerson("Nevva", "Gothere"),     "SampleTabulaScenario.scn:25", "wfEditPerson.AddPerson(\"Nevva\", \"Gothere\")");
        }
    }


    //  Code below not generated, just here to support PBI purposes
    public class EditPersonWorkflow
    {
        public void AddPerson(string firstName, string lastName)
        {
            //la de dah
        }

        public void AddPerson_but_fail(string firstName, string lastName)
        {
            throw new AssertionException("Made you look");
        }

        public void Add_some_more_but_die_horribly(string firstName)
        {
            throw new Exception("Not for " + firstName);
        }

    }

    public class AssertionException : Exception
    {
        public AssertionException( string message )
            : base(message)
        { }
    }
}
